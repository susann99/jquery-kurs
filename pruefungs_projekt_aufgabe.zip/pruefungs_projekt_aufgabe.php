<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Tag 21 Prüfung</title>
        <style>
       
        </style>
        <script type="text/javascript" src="js/jquery-1.9.1.js"></script>
        <script type="text/javascript">
	    
        </script>
    </head>
    <body>
       1. Vorbereitung:
       - Bilder in Verzeichnis laden
       - DIV-Gerüst mit Kopf, Left und Content
       2. Leftmenu: 
       - Bilder als Lightbox, 
	    - unten eine Filmleiste, darüber großes Bild mit Beschreibung
	    - bilder als img-tag, title als beschreibung
	    - div:leinwand, div:filmstreifen, div:info
       - Diashow
	    - script läuft automatisch
       - Kopf, Logokram
       
    </body>
</html>
